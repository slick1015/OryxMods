﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MelonLoader;

namespace $safeprojectname$
{
    public class $safeprojectname$ : MelonMod
    {
        public override void OnApplicationStart()
        {
            MelonLogger.Msg("Hello from Template Mod!");
        }
    }
}
